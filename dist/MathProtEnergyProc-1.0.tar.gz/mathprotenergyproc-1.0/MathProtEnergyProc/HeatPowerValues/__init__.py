from MathProtEnergyProcBase.HeatPowerValues import *
