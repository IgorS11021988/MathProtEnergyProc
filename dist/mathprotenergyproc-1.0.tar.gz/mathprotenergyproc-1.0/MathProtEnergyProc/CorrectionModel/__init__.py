from MathProtEnergyProcBase.CorrectionModel import *
